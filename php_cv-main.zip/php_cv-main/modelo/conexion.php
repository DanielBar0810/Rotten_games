<?php
$conexion = mysqli_connect("localhost","root","","rotten_tomatoes");
// $conexion->set_charset("utf8");
?>