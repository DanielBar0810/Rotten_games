<!DOCTYPE html>
<html lang="en">

<head>
  <title>Rotten Games</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="vistas/styles.css">
  <link rel="website icon" type="png" href="img/logo.png">
  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <!-- Font Awesome -->
      <script
         src="https://kit.fontawesome.com/846e98f337.js"
         crossorigin="anonymous"
      ></script>
</head>

<body>